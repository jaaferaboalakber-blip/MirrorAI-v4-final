import fs from 'node:fs';
import assert from 'node:assert/strict';

const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
for(const dep of ['react','react-dom','express','openai','vite','@vitejs/plugin-react']) assert(pkg.dependencies[dep],`missing dependency ${dep}`);
assert.equal(pkg.scripts.build,'vite build');
assert.equal(pkg.scripts.start,'node server/index.js');

function parseWhatsApp(text){
 const out=[]; let cur=null; let n=0;
 const patterns=[
  /^\[?(\d{1,4}[\/\.\-]\d{1,2}[\/\.\-]\d{1,4}),\s*(\d{1,2}:\d{2}(?::\d{2})?\s*(?:AM|PM|ص|م)?)\]?\s*[-–—:]\s*([^:]+):\s?(.*)$/iu,
  /^(\d{1,4}[\/\.\-]\d{1,4}[\/\.\-]\d{1,4}),\s*(\d{1,2}:\d{2}(?::\d{2})?\s*(?:AM|PM|ص|م)?)\s*[-–—]\s*([^:]+):\s?(.*)$/iu
 ];
 const ignored=/messages and calls are end-to-end encrypted|الرسائل والمكالمات محمية|media omitted|الوسائط مفقودة|<media omitted>|هذه الرسالة محذوفة|this message was deleted/i;
 for(const raw of String(text).replace(/\r/g,'').split('\n')){const line=raw.trimEnd();let m=null;for(const p of patterns){m=line.match(p);if(m)break}if(m){cur={id:`m${n++}`,date:m[1],time:m[2].trim(),speaker:m[3].trim(),text:m[4].trim()};if(cur.text&&!ignored.test(cur.text))out.push(cur)}else if(cur&&line.trim()&&!ignored.test(line.trim()))cur.text+='\n'+line.trim();}
 return out.filter(x=>x.text.trim());
}

const sample=`28/08/2026, 7:02 PM - Jaafer: هلا شلونچ؟\n28/08/2026, 7:03 PM - Sara: هلا حبيبي\nرد متعدد\n28/08/2026, 7:04 PM - Jaafer: <media omitted>\n[28/08/2026, 19:05:12] Sara: تمام حبيبي`;
const parsed=parseWhatsApp(sample);
assert.equal(parsed.length,3);
assert.equal(parsed[1].text,'هلا حبيبي\nرد متعدد');
assert.equal(parsed[2].text,'تمام حبيبي');
assert.match(parsed[0].text,/هلا شلونچ/);

const files=['server/index.js','src/main.jsx','src/styles.css','index.html','vite.config.js','public/manifest.webmanifest','public/sw.js','public/icon.svg','.replit'];
for(const f of files)assert(fs.existsSync(f),`missing ${f}`);
const src=fs.readFileSync('src/main.jsx','utf8');
assert(src.includes('indexedDB'),'IndexedDB storage missing');
assert(src.includes('/api/analyze'),'analysis endpoint missing');
assert(src.includes('/api/chat'),'chat endpoint missing');
assert(src.includes('exportBackup'),'backup missing');
const server=fs.readFileSync('server/index.js','utf8');
assert(server.includes("store: false"),'privacy store:false missing');
assert(server.includes('gpt-5.6-luna'),'current default model missing');
assert(server.includes('json_schema'),'structured output missing');
console.log('SMOKE_TEST_OK');
