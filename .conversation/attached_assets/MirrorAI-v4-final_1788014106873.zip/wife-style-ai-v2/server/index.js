import express from 'express';
import OpenAI from 'openai';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '25mb' }));

const client = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;
const MODEL = process.env.OPENAI_MODEL || 'gpt-5.6-luna';
const MAX_INPUT = 220000;

const BASE = `أنت «مرآة الأسلوب»: محلل محادثات دقيق. تدرس النص والسياق والأنماط المتكررة، ولا تدّعي قراءة الأفكار أو معرفة النوايا الداخلية. افصل الدليل عن الاستنتاج. لا تشخّص نفسياً ولا تحكم أخلاقياً ولا تحاول إثارة الغيرة أو الشك. لا تجعل نمطاً عابراً صفة ثابتة. عند تعارض القرائن اذكر التعارض. استخدم العربية العراقية الطبيعية عندما تناسب المستخدم. احترم الخصوصية ولا تطلب بيانات لا تحتاجها.`;

function guard(res) {
  if (!client) {
    res.status(503).json({ error: 'الذكاء الاصطناعي غير مفعّل. أضف OPENAI_API_KEY في Secrets.' });
    return false;
  }
  return true;
}

function safe(v, n = MAX_INPUT) { return String(v ?? '').slice(0, n); }

function parseJsonFallback(text) {
  const cleaned = String(text || '').trim().replace(/^```(?:json)?\s*/i, '').replace(/```$/i, '').trim();
  return JSON.parse(cleaned);
}

async function aiText(instructions, input, format) {
  const payload = {
    model: MODEL,
    instructions,
    input,
    store: false,
    ...(format ? { text: { format } } : {})
  };
  const response = await client.responses.create(payload);
  return response.output_text || '';
}

const profileSchema = {
  type: 'json_schema', name: 'style_profile', strict: true,
  schema: {
    type: 'object', additionalProperties: false,
    properties: {
      summary: { type: 'string' },
      styleFingerprint: { type: 'array', items: { type: 'string' } },
      patterns: { type: 'array', items: { type: 'string' } },
      phrases: { type: 'array', items: { type: 'string' } },
      signals: { type: 'array', items: { type: 'string' } },
      cautions: { type: 'array', items: { type: 'string' } },
      situations: { type: 'array', items: { type: 'string' } },
      examples: { type: 'array', items: { type: 'string' } }
    }, required: ['summary','styleFingerprint','patterns','phrases','signals','cautions','situations','examples']
  }
};

const memorySchema = {
  type: 'json_schema', name: 'style_memories', strict: true,
  schema: {
    type: 'object', additionalProperties: false,
    properties: {
      memories: {
        type: 'array', items: {
          type: 'object', additionalProperties: false,
          properties: {
            title: { type: 'string' }, category: { type: 'string' }, trigger: { type: 'string' },
            context: { type: 'string' }, herMessage: { type: 'string' }, responsePattern: { type: 'string' },
            keywords: { type: 'array', items: { type: 'string' } }, evidence: { type: 'string' }, confidence: { type: 'number' }
          }, required: ['title','category','trigger','context','herMessage','responsePattern','keywords','evidence','confidence']
        }
      }
    }, required: ['memories']
  }
};

const analysisSchema = {
  type: 'json_schema', name: 'conversation_analysis', strict: true,
  schema: {
    type: 'object', additionalProperties: false,
    properties: {
      likelyState: { type: 'string' }, confidence: { type: 'number' }, interpretation: { type: 'string' },
      evidence: { type: 'array', items: { type: 'string' } }, similarPatterns: { type: 'array', items: { type: 'string' } },
      alternatives: { type: 'array', items: { type: 'string' } }, suggestedResponses: { type: 'array', items: { type: 'string' } },
      whatNotToDo: { type: 'array', items: { type: 'string' } }, uncertainty: { type: 'string' }
    }, required: ['likelyState','confidence','interpretation','evidence','similarPatterns','alternatives','suggestedResponses','whatNotToDo','uncertainty']
  }
};

app.get('/api/health', (_, res) => res.json({ ok: true, model: MODEL, aiConfigured: Boolean(client) }));

app.post('/api/profile', async (req, res) => {
  if (!guard(res)) return;
  try {
    const { herName, messages = [] } = req.body || {};
    if (!herName || !Array.isArray(messages) || !messages.length) return res.status(400).json({ error: 'لا توجد رسائل كافية لبناء البصمة.' });
    const sample = messages.map(m => `${m.date || ''} ${m.time || ''} | ${m.speaker}: ${m.text}`).join('\n').slice(0, MAX_INPUT);
    const prompt = `ابنِ ملفاً أسلوبياً للشخص «${safe(herName, 200)}» اعتماداً على الرسائل فقط. أعد JSON وفق المخطط. ركز على اللهجة، طول الرد، الاختصار، الترقيم، الإيموجي، الكلمات المتكررة وسياقات استخدامها، طريقة فتح/إنهاء النقاش، الاعتذار، المزاح، الاهتمام والانزعاج عندما يظهر بالدليل، والفروق بين السياقات. لا تجعل أي استنتاج نفسياً ثابتاً بلا دليل. كل عنصر مختصر ومفيد.\n\nالرسائل:\n${sample}`;
    const out = await aiText(BASE, prompt, profileSchema);
    res.json(JSON.parse(out));
  } catch (e) { res.status(500).json({ error: e.message || 'فشل بناء البصمة.' }); }
});

app.post('/api/memory-batch', async (req, res) => {
  if (!guard(res)) return;
  try {
    const { herName, messages = [] } = req.body || {};
    if (!Array.isArray(messages) || !messages.length) return res.json({ memories: [] });
    const sample = messages.map((m, i) => `${i}|${m.date || ''} ${m.time || ''}|${m.speaker}|${m.text}`).join('\n').slice(0, MAX_INPUT);
    const prompt = `استخرج بطاقات ذاكرة أسلوبية من هذه الدفعة من محادثة «${safe(herName, 200)}». اختر فقط المواقف الواضحة التي يمكن الرجوع إليها لاحقاً عند تحليل موقف جديد، ولا تلخص كل الرسائل. ركز على اختلاف أسلوبها حسب السياق. category يجب أن تكون واحدة من: حب/اهتمام، زعل/انزعاج، خلاف، اعتذار/مصالحة، مزاح، غيرة/حساسية، طلب/احتياج، عادي، غير واضح. herMessage مقتطف قصير لا يتجاوز 30 كلمة. confidence بين 0 و100. الحد الأقصى 20 بطاقة. لا تخترع معلومات.\n\nالدفعة:\n${sample}`;
    const out = await aiText(BASE, prompt, memorySchema);
    res.json(JSON.parse(out));
  } catch (e) { res.status(500).json({ error: e.message || 'فشل استخراج الذاكرة.' }); }
});

app.post('/api/analyze', async (req, res) => {
  if (!guard(res)) return;
  try {
    const { herName, question, profile = {}, memory = [] } = req.body || {};
    if (!question?.trim()) return res.status(400).json({ error: 'أدخل الموقف أولاً.' });
    const mem = memory.map((x, i) => `#${i + 1} [${x.category}] ${x.title}\nالسياق: ${x.context}\nرسالتها: ${x.herMessage}\nالنمط: ${x.responsePattern}\nالكلمات: ${(x.keywords || []).join(', ')}\nالدليل: ${x.evidence}`).join('\n\n').slice(0, 140000);
    const prompt = `حلّل الموقف الجديد مع «${safe(herName, 200)}» باستخدام ملف الأسلوب وبطاقات الذاكرة كقرائن، وليس كحقائق عن النية. أعد JSON وفق المخطط. إذا كان النص غير كافٍ، قل ذلك وخفّض الثقة. صغ القراءة العاطفية كاحتمال لا كيقين. اقترح ردين طبيعيين ومحترمين وغير متلاعبين.\n\nملف الأسلوب:\n${JSON.stringify(profile).slice(0, 50000)}\n\nبطاقات الذاكرة:\n${mem}\n\nالموقف الجديد:\n${safe(question, 70000)}`;
    const out = await aiText(BASE, prompt, analysisSchema);
    res.json(JSON.parse(out));
  } catch (e) { res.status(500).json({ error: e.message || 'فشل تحليل الموقف.' }); }
});

app.post('/api/chat', async (req, res) => {
  if (!guard(res)) return;
  try {
    const { herName, profile = {}, memory = [], chat = [], message } = req.body || {};
    if (!message?.trim()) return res.status(400).json({ error: 'اكتب سؤالك.' });
    const mem = memory.map((x, i) => `#${i + 1} [${x.category}] ${x.title}: ${x.context} | هي: ${x.herMessage} | النمط: ${x.responsePattern}`).join('\n').slice(0, 90000);
    const convo = chat.map(x => `${x.role === 'user' ? 'المستخدم' : 'المساعد'}: ${x.content}`).join('\n').slice(-30000);
    const prompt = `أنت المساعد داخل «مرآة الأسلوب». أجب بالعربية العراقية الطبيعية عندما تناسب. اعتمد على ملف الأسلوب والذكريات المسترجعة وسياق الدردشة. إذا سأل المستخدم «شنو تقصد؟» أعطه القراءة الأقرب ثم الدليل والبدائل. إذا سأل «شنو أرد؟» اقترح ردوداً طبيعية ومحترمة وغير متلاعبة. لا تقل إنك تعرف ما في داخلها. لا تحوّل الذاكرة إلى تشخيص أو حكم.\n\nالشخص: ${safe(herName, 200)}\nملف الأسلوب: ${JSON.stringify(profile).slice(0, 50000)}\nالذكريات المسترجعة:\n${mem}\nسياق الدردشة:\n${convo}\nسؤال المستخدم: ${safe(message, 30000)}`;
    const out = await aiText(BASE, prompt);
    res.json({ answer: out });
  } catch (e) { res.status(500).json({ error: e.message || 'فشل الرد.' }); }
});

const dist = path.resolve(__dirname, '../dist');
app.use(express.static(dist));
app.use((req, res) => {
  if (req.method !== 'GET') return res.status(404).json({ error: 'Not found' });
  res.sendFile(path.join(dist, 'index.html'));
});

const port = Number(process.env.PORT || 3000);
app.listen(port, '0.0.0.0', () => console.log(`Mirat Al Uslub listening on ${port}`));
