import React, { useEffect, useMemo, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import './styles.css';

const META_KEY = 'mirat-style-v4-meta';
const DB_NAME = 'mirat-style-v4-db';
const DB_VERSION = 1;
const emptyProfile = { summary:'', styleFingerprint:[], patterns:[], phrases:[], signals:[], cautions:[], situations:[], examples:[] };
const STOP = new Set('من في على عن إلى الى و أو او أن ان هي هو هذا هذه ذلك ذاك مع ما لا لم لن لي لك لها له انا أنا انت أنت نحن هم كان كانت يكون تكون قد يا كل بس مو موش اكو شنو شلون ليش وين هذي هاي هذا ذاك الذي التي'.split(/\s+/));

function openDB(){
  return new Promise((resolve,reject)=>{
    const r=indexedDB.open(DB_NAME,DB_VERSION);
    r.onupgradeneeded=()=>{const db=r.result;if(!db.objectStoreNames.contains('messages'))db.createObjectStore('messages',{keyPath:'id'});};
    r.onsuccess=()=>resolve(r.result); r.onerror=()=>reject(r.error);
  });
}
async function dbPutMany(items){const db=await openDB();return new Promise((resolve,reject)=>{const tx=db.transaction('messages','readwrite'),s=tx.objectStore('messages');for(const x of items)s.put(x);tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);});}
async function dbGetAll(){const db=await openDB();return new Promise((resolve,reject)=>{const tx=db.transaction('messages','readonly'),r=tx.objectStore('messages').getAll();r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});}
async function dbClear(){const db=await openDB();return new Promise((resolve,reject)=>{const tx=db.transaction('messages','readwrite');tx.objectStore('messages').clear();tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);});}

function parseWhatsApp(text){
  const out=[]; let cur=null; let n=0;
  const patterns=[
    /^\[?(\d{1,4}[\/\.\-]\d{1,2}[\/\.\-]\d{1,4}),\s*(\d{1,2}:\d{2}(?::\d{2})?\s*(?:AM|PM|ص|م)?)\]?\s*[-–—:]\s*([^:]+):\s?(.*)$/iu,
    /^(\d{1,4}[\/\.\-]\d{1,2}[\/\.\-]\d{1,4}),\s*(\d{1,2}:\d{2}(?::\d{2})?\s*(?:AM|PM|ص|م)?)\s*[-–—]\s*([^:]+):\s?(.*)$/iu
  ];
  const ignored=/messages and calls are end-to-end encrypted|الرسائل والمكالمات محمية|media omitted|الوسائط مفقودة|<media omitted>|هذه الرسالة محذوفة|this message was deleted/i;
  for(const raw of String(text).replace(/\r/g,'').split('\n')){
    const line=raw.trimEnd(); let m=null; for(const p of patterns){m=line.match(p);if(m)break;}
    if(m){const speaker=m[3].trim();const msg=m[4].trim();cur={id:`m_${Date.now()}_${n++}_${Math.random().toString(36).slice(2)}`,date:m[1],time:m[2].trim(),speaker,text:msg};if(msg&&!ignored.test(msg))out.push(cur);}
    else if(cur&&line.trim()&&!ignored.test(line.trim()))cur.text+='\n'+line.trim();
  }
  return out.filter(x=>x.text.trim());
}
function tokenize(s){return String(s||'').toLowerCase().normalize('NFKC').replace(/https?:\/\/\S+/g,' ').replace(/[^\p{L}\p{N}\s]/gu,' ').split(/\s+/).filter(w=>w.length>1&&!STOP.has(w));}
function makeTerms(s){return [...new Set(tokenize(s))];}
function score(q,m){
  const qTerms=makeTerms(q); if(!qTerms.length)return 0;
  const text=[m.title,m.trigger,m.context,m.herMessage,m.responsePattern,(m.keywords||[]).join(' ')].join(' '); const terms=new Set(tokenize(text));
  let hit=0;for(const t of qTerms)if(terms.has(t))hit++;
  const phrase=String(m.herMessage||'').trim().toLowerCase(); if(phrase.length>8&&String(q).toLowerCase().includes(phrase))hit+=5;
  return hit/(Math.sqrt(qTerms.length)*Math.sqrt(Math.max(terms.size,1)))*10;
}
function retrieve(q, memories, messages, her, limit=18){
  const a=memories.map(m=>({...m,_score:score(q,m)})).filter(x=>x._score>0);
  const b=messages.filter(m=>m.speaker===her).map(m=>({title:'رسالة سابقة',category:'رسالة مشابهة',context:m.text,herMessage:m.text,responsePattern:'',keywords:makeTerms(m.text),evidence:'رسالة فعلية من الأرشيف',confidence:50,_score:score(q,{context:m.text,herMessage:m.text})})).filter(x=>x._score>0);
  return [...a,...b].sort((x,y)=>y._score-x._score).slice(0,limit);
}
function sampleForProfile(messages, max=18000){
  if(messages.length<=max)return messages;
  const head=messages.slice(0,Math.min(4000,messages.length)); const tail=messages.slice(-Math.min(6000,messages.length));
  const step=Math.max(1,Math.floor(messages.length/Math.max(1,max-head.length-tail.length))); const middle=[]; for(let i=4000;i<messages.length-6000;i+=step)middle.push(messages[i]);
  return [...head,...middle,...tail].slice(0,max);
}
function makeWindows(messages, her, size=40){
  const out=[]; for(let i=0;i<messages.length;i+=size){const win=messages.slice(i,i+size);if(win.some(x=>x.speaker===her))out.push(win);} return out;
}
function Card({title,icon='✦',children,wide=false}){return <section className={'card '+(wide?'wide':'')}><div className="ct"><span>{icon}</span><h2>{title}</h2></div>{children}</section>}

function App(){
 const [messages,setMessages]=useState([]),[files,setFiles]=useState([]),[her,setHer]=useState(''),[me,setMe]=useState(''),[profile,setProfile]=useState(emptyProfile),[memories,setMemories]=useState([]),[tab,setTab]=useState('chat'),[question,setQuestion]=useState(''),[analysis,setAnalysis]=useState(null),[busy,setBusy]=useState(false),[notice,setNotice]=useState(''),[chat,setChat]=useState([]),[chatInput,setChatInput]=useState(''),[progress,setProgress]=useState(0),[ready,setReady]=useState(false),[search,setSearch]=useState('');
 const fileRef=useRef();
 useEffect(()=>{(async()=>{try{const meta=JSON.parse(localStorage.getItem(META_KEY)||'{}');setFiles(meta.files||[]);setHer(meta.her||'');setMe(meta.me||'');setProfile(meta.profile||emptyProfile);setMemories(meta.memories||[]);setChat(meta.chat||[]);setMessages(await dbGetAll());}catch(e){setNotice('تعذر فتح الذاكرة المحلية: '+e.message)}finally{setReady(true)}})();},[]);
 useEffect(()=>{if(!ready)return;localStorage.setItem(META_KEY,JSON.stringify({files,her,me,profile,memories,chat}));},[files,her,me,profile,memories,chat,ready]);
 const names=useMemo(()=>[...new Set(messages.map(x=>x.speaker))].sort((a,b)=>a.localeCompare(b)),[messages]);
 const herMsgs=useMemo(()=>messages.filter(x=>x.speaker===her),[messages,her]);
 const retrieved=useMemo(()=>retrieve(question||chatInput,memories,messages,her,18),[question,chatInput,memories,messages,her]);
 const visibleMemory=useMemo(()=>{const q=search.trim();return q?memories.map(m=>({...m,_score:score(q,m)})).filter(m=>m._score>0).sort((a,b)=>b._score-a._score):memories;},[search,memories]);

 async function importFiles(list){
   const fs=[...list].filter(f=>/\.txt$/i.test(f.name)); if(!fs.length){setNotice('ارفع ملف TXT من تصدير واتساب.');return;}
   setBusy(true);setNotice('جاري قراءة ملفات واتساب…');
   try{let total=0;const newMeta=[];const existing=new Set(messages.map(x=>`${x.date}|${x.time}|${x.speaker}|${x.text}`));const added=[];
     for(const f of fs){const parsed=parseWhatsApp(await f.text());let unique=0;for(const m of parsed){const k=`${m.date}|${m.time}|${m.speaker}|${m.text}`;if(existing.has(k))continue;existing.add(k);added.push(m);unique++;}newMeta.push({name:f.name,count:unique,addedAt:new Date().toISOString()});total+=unique;}
     await dbPutMany(added);setMessages(await dbGetAll());setFiles(prev=>[...prev,...newMeta]);if(!her&&added[0])setHer(added[0].speaker);setNotice(`تمت إضافة ${total.toLocaleString('ar')} رسالة جديدة.`);setTab('data');
   }catch(e){setNotice('فشل استيراد المحادثة: '+e.message)}finally{setBusy(false);if(fileRef.current)fileRef.current.value='';}
 }
 async function build(){
   if(!herMsgs.length){setNotice('اختر اسم زوجتك أولاً.');setTab('data');return;}
   setBusy(true);setProgress(0);setNotice('جاري بناء البصمة والذاكرة…');
   try{
     const pr=await fetch('/api/profile',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({herName:her,messages:sampleForProfile(herMsgs)})});
     const pd=await pr.json();if(!pr.ok)throw Error(pd.error||'فشل البصمة');setProfile(pd);
     const windows=makeWindows(messages,her,36); const selected=windows.length>120?windows.filter((_,i)=>i%Math.ceil(windows.length/120)===0):windows; const all=[];
     for(let i=0;i<selected.length;i++){
       const context=selected[i];const r=await fetch('/api/memory-batch',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({herName:her,messages:context})});const d=await r.json();if(!r.ok)throw Error(d.error||'فشل الذاكرة');all.push(...(d.memories||[]));setProgress(Math.round((i+1)/selected.length*100));
     }
     const dedup=new Map();for(const m of all){const k=[m.category,m.title,m.herMessage].join('|').toLowerCase();if(!dedup.has(k)||dedup.get(k).confidence<m.confidence)dedup.set(k,m);}setMemories([...dedup.values()].slice(0,1200));setNotice(`اكتملت البصمة والذاكرة: ${dedup.size.toLocaleString('ar')} موقفاً.`);setTab('profile');
   }catch(e){setNotice(e.message)}finally{setBusy(false)}
 }
 async function analyze(){if(!question.trim()){setNotice('ألصق الموقف أولاً.');return;}setBusy(true);setAnalysis(null);setNotice('جاري مقارنة الموقف بذاكرتها…');try{const mem=retrieved.slice(0,30);const r=await fetch('/api/analyze',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({herName:her,question,profile,memory:mem})});const d=await r.json();if(!r.ok)throw Error(d.error);setAnalysis(d);setNotice('اكتمل التحليل.')}catch(e){setNotice(e.message)}finally{setBusy(false)}}
 async function sendChat(){if(!chatInput.trim()||busy)return;const msg=chatInput.trim();setChatInput('');const next=[...chat,{role:'user',content:msg}];setChat(next);setBusy(true);try{const mem=retrieve(msg,memories,messages,her,18);const r=await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({herName:her,profile,memory:mem,chat:next,message:msg})});const d=await r.json();if(!r.ok)throw Error(d.error);setChat(c=>[...c,{role:'assistant',content:d.answer}]);}catch(e){setChat(c=>[...c,{role:'assistant',content:'تعذر تنفيذ الطلب: '+e.message}]);}finally{setBusy(false)}}
 async function clearAll(){if(!confirm('سيتم حذف الرسائل والذاكرة والإعدادات من هذا الجهاز. هل أنت متأكد؟'))return;await dbClear();localStorage.removeItem(META_KEY);location.reload();}
 function exportBackup(){const blob=new Blob([JSON.stringify({version:4,files,her,me,profile,memories,chat,messages},null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`mirat-al-uslub-backup-${new Date().toISOString().slice(0,10)}.json`;a.click();URL.revokeObjectURL(a.href);}
 async function importBackup(file){try{const data=JSON.parse(await file.text());if(!Array.isArray(data.messages))throw Error('ملف النسخة الاحتياطية غير صالح');await dbClear();await dbPutMany(data.messages);setMessages(data.messages);setFiles(data.files||[]);setHer(data.her||'');setMe(data.me||'');setProfile(data.profile||emptyProfile);setMemories(data.memories||[]);setChat(data.chat||[]);setNotice('تم استرجاع النسخة الاحتياطية بنجاح.');}catch(e){setNotice('فشل الاسترجاع: '+e.message)}}
 if(!ready)return <div className="loading">جاري تجهيز الذاكرة المحلية…</div>;
 return <div className="app"><header><div className="brand"><div className="logo">م</div><div><b>مرآة الأسلوب</b><small>ذاكرة أسلوبية خاصة</small></div></div><div className="head-actions"><button onClick={()=>fileRef.current?.click()}>＋ واتساب</button><button className="ghost" onClick={exportBackup}>نسخة احتياطية</button><button className="ghost" onClick={clearAll}>مسح</button></div><input ref={fileRef} hidden type="file" accept=".txt,text/plain" multiple onChange={e=>importFiles(e.target.files)}/></header>
 <main><div className="hero"><div><span className="eyebrow">يتعلم من السياق الحقيقي، لا من التخمين</span><h1>مو بس يفسّر رسالة.<br/><em>يتذكر السياق أيضاً.</em></h1><p>ارفع محادثات واتساب القديمة. التطبيق يفهرسها محلياً، يبني بصمة لأسلوبها، ثم يسترجع المواقف الأقرب قبل كل تحليل.</p></div><div className="orb">✦</div></div>
 <nav><button className={tab==='chat'?'on':''} onClick={()=>setTab('chat')}>المحادثة</button><button className={tab==='analyze'?'on':''} onClick={()=>setTab('analyze')}>تحليل موقف</button><button className={tab==='profile'?'on':''} onClick={()=>setTab('profile')}>بصمتها</button><button className={tab==='memory'?'on':''} onClick={()=>setTab('memory')}>الذاكرة <i>{memories.length}</i></button><button className={tab==='data'?'on':''} onClick={()=>setTab('data')}>البيانات</button></nav>
 {notice&&<div className="notice">{busy?'◌ ':''}{notice}{busy&&progress?` ${progress}%`:''}</div>}
 {tab==='chat'&&<div className="chat-wrap"><div className="chatbox"><div className="chat-head"><div><b>مساعد مرآة الأسلوب</b><small>{her?`مرجع: ${her}`:'أضف محادثة وحدد الشخص أولاً'}</small></div><span>●</span></div><div className="messages">{chat.length===0?<div className="welcome"><div className="welcome-icon">✦</div><h2>شلون أساعدك؟</h2><p>اسألني عن رد، موقف، أو طريقة مناسبة للرد عليها.</p><div className="quick"><button onClick={()=>setChatInput('شنو أكثر الأشياء اللي تميز أسلوب كلامها؟')}>حلل أسلوبها</button><button onClick={()=>setChatInput('هل هي زعلانة من هذا الرد؟ وما الأدلة؟')}>هل هي زعلانة؟</button><button onClick={()=>setChatInput('شنو أفضل رد طبيعي على هذا الموقف؟')}>شنو أرد؟</button></div></div>:chat.map((m,i)=><div key={i} className={'bubble '+m.role}>{m.content}</div>)}{busy&&<div className="bubble assistant typing">جاري التفكير…</div>}</div><div className="composer"><textarea value={chatInput} onChange={e=>setChatInput(e.target.value)} onKeyDown={e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();sendChat()}}} placeholder="اكتب سؤالك…"/><button onClick={sendChat} disabled={busy}>➤</button></div></div></div>}
 {tab==='analyze'&&<div className="two"><Card title="الموقف الجديد" icon="⌁"><textarea className="bigtext" value={question} onChange={e=>setQuestion(e.target.value)} placeholder={'الصق المحادثة هنا…\nأنا: ...\nهي: ...'}/><button className="primary" onClick={analyze} disabled={busy||!question.trim()}>حلّل مقارنةً بذاكرتها ✦</button>{retrieved.length>0&&<div className="retrieval"><small>استرجاع محلي: {retrieved.length} قرائن مرتبطة.</small>{retrieved.slice(0,5).map((m,i)=><span key={i}>{m.title}</span>)}</div>}</Card>{analysis&&<div className="result"><Card title="القراءة الأقرب" icon="◎"><div className="state"><b>{analysis.likelyState||'غير محسوم'}</b><span>{Math.round(analysis.confidence||0)}% ثقة</span></div><p className="biganswer">{analysis.interpretation}</p><div className="uncertainty">{analysis.uncertainty}</div></Card><Card title="الأدلة والأنماط المشابهة" icon="⌕"><ul>{[...(analysis.evidence||[]),...(analysis.similarPatterns||[])].map((x,i)=><li key={i}>{x}</li>)}</ul></Card><Card title="احتمالات أخرى وردود مقترحة" icon="◇"><ul>{(analysis.alternatives||[]).map((x,i)=><li key={i}>{x}</li>)}</ul><div className="reply-list">{(analysis.suggestedResponses||[]).map((x,i)=><div key={i}><b>رد {i+1}:</b> {x}</div>)}</div><div className="avoid">{(analysis.whatNotToDo||[]).map((x,i)=><span key={i}>تجنب: {x}</span>)}</div></Card></div>}</div>}
 {tab==='profile'&&<div className="profile"><Card title="الخلاصة" icon="✦" wide><p className="summary">{profile.summary||'لم تُبنَ البصمة بعد. اذهب إلى البيانات ثم اضغط بناء/تحديث.'}</p><div className="chips">{(profile.styleFingerprint||[]).map((x,i)=><span key={i}>{x}</span>)}</div></Card><Card title="الأنماط المتكررة" icon="↻"><ul>{(profile.patterns||[]).map((x,i)=><li key={i}>{x}</li>)}</ul></Card><Card title="العبارات والسياقات" icon="❝"><ul>{(profile.phrases||[]).map((x,i)=><li key={i}>{x}</li>)}</ul></Card><Card title="مواقفها حسب السياق" icon="⌘"><ul>{(profile.situations||[]).map((x,i)=><li key={i}>{x}</li>)}</ul></Card><Card title="إشارات وحدود التحليل" icon="⚑"><ul>{[...(profile.signals||[]),...(profile.cautions||[])].map((x,i)=><li key={i}>{x}</li>)}</ul></Card></div>}
 {tab==='memory'&&<div className="memory-page"><Card title="الذاكرة الأسلوبية" icon="⌘" wide><div className="stats"><div><b>{messages.length.toLocaleString('ar')}</b><span>رسالة مفهرسة محلياً</span></div><div><b>{herMsgs.length.toLocaleString('ar')}</b><span>رسالة لها</span></div><div><b>{memories.length.toLocaleString('ar')}</b><span>موقف أسلوبي</span></div></div><input className="search" value={search} onChange={e=>setSearch(e.target.value)} placeholder="ابحث داخل الذاكرة…"/><p className="muted">البحث والاسترجاع الأولي يعملان محلياً، ثم تُرسل القرائن المختارة فقط إلى نموذج الذكاء الاصطناعي عند التحليل.</p></Card><div className="memory-grid">{visibleMemory.slice(0,160).map((m,i)=><Card key={i} title={m.title||'موقف'} icon="•"><span className="cat">{m.category}</span><p>{m.context}</p>{m.herMessage&&<blockquote>«{m.herMessage}»</blockquote>}<small>{m.responsePattern}</small></Card>)}</div></div>}
 {tab==='data'&&<div className="two"><Card title="محادثات واتساب" icon="💬"><div className="drop" onClick={()=>fileRef.current?.click()}><b>＋ أضف ملفات TXT</b><small>يدعم عدة ملفات ويزيل الرسائل المكررة. كل الرسائل تُفهرس محلياً.</small></div>{files.map((f,i)=><div className="file" key={i}><span>{f.name}</span><small>{Number(f.count||0).toLocaleString('ar')} رسالة</small></div>)}</Card><Card title="إعداد المشاركين وبناء الذاكرة" icon="👤"><label>زوجتك<select value={her} onChange={e=>setHer(e.target.value)}><option value="">اختر الاسم</option>{names.map(n=><option key={n}>{n}</option>)}</select></label><label>اسمك<input value={me} onChange={e=>setMe(e.target.value)} placeholder="اختياري"/></label><button className="primary" onClick={build} disabled={busy||!herMsgs.length}>ابنِ / حدّث البصمة والذاكرة</button><div className="privacy">المحادثات الخام محفوظة في IndexedDB داخل جهازك. لا تُرسل تلقائياً. عند البناء/التحليل، تُرسل عينات وقرائن لازمة فقط إلى خادم الذكاء الاصطناعي.</div><hr/><label className="backup">استرجاع نسخة احتياطية<input type="file" accept="application/json,.json" onChange={e=>e.target.files[0]&&importBackup(e.target.files[0])}/></label></Card></div>}
 </main><footer>مرآة الأسلوب لا تدّعي معرفة النوايا الداخلية. هي تقارن اللغة والسياق السابق وتعرض الاحتمال مع أدلته وحدوده. كلما كانت المحادثات أكثر تنوعاً، صار الاسترجاع أدق.</footer></div>
}
if('serviceWorker' in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}));
createRoot(document.getElementById('root')).render(<App/>);
